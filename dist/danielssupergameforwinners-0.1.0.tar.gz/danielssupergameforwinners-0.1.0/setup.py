from setuptools import setup, find_packages
setup(
name='danielssupergameforwinners',
version='0.1.0',
author='Daniel Hutchings',
author_email='thewakemaster@gmail.com',
description='The bestest game in the whole world.',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)